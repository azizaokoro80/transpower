import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseKey);

// Auth utils (optional)
export async function getUser() {
  const {
    data: { user },
    error
  } = await supabase.auth.getUser();
  if (error) console.error(error);
  return user;
}

export async function signOut() {
  await supabase.auth.signOut();
}

export async function signInWithEmail(email: string) {
  const { error } = await supabase.auth.signInWithOtp({ email });
  if (error) console.error(error);
}
