exports.handler = async function(event, context) {
  return {
    statusCode: 200,
    body: JSON.stringify({ price: "64250.50" })
  };
};