exports.handler = async function(event, context) {
  return {
    statusCode: 200,
    body: JSON.stringify({
      lgbtq: [{ name: "GLCCB", description: "Community Center for LGBTQ+ Baltimoreans", link: "https://glccb.org" }],
      housing: [{ name: "Baltimore Housing Aid", description: "Shelter & voucher help", link: "#" }],
      jobs: [{ name: "YouthWorks", description: "Job placement for city youth", link: "https://youthworks.oedworks.com" }],
      mentalHealth: [{ name: "Beyond Health PRP", description: "Psych rehab and mental health", link: "https://beyondhealthprp.com" }]
    })
  };
};